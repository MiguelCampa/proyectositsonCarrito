/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package mx.itson.carrito.enums;

/**
 *
 * @author alumnog
 */
public enum TipoTransmisión {
    AUTOMATICO,
    ESTANDAR,
    HÍDRAULICA;
}
